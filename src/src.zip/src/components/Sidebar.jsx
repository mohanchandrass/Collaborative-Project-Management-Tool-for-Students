import React, { useContext, useState, useRef, useEffect } from 'react';
import { ProjectContext } from '../context/ProjectContext';
import { AuthContext } from '../context/AuthContext';
import { FiPlus, FiHome, FiLogOut } from 'react-icons/fi';
import { BsPersonFill } from 'react-icons/bs';

const Sidebar = () => {
  const { projects, createProject, activeProject, setActiveProject } = useContext(ProjectContext);
  const { user, logout } = useContext(AuthContext);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const userMenuRef = useRef(null);

  const handleCreateProject = () => {
    if (newProjectName.trim()) {
      createProject(newProjectName);
      setNewProjectName('');
      setShowCreateModal(false);
    }
  };

  const handleClickOutside = (event) => {
    if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
      setShowUserMenu(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div style={{
      width: '72px',
      backgroundColor: '#1e1e1e',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      position: 'fixed',
      left: 0,
      top: 0
    }}>
      {/* Server List */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        paddingTop: '12px',
        gap: '8px'
      }}>
        {/* Home Button */}
        <div 
          style={{
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            backgroundColor: activeProject === null ? '#363636' : '#2a2a2a',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            cursor: 'pointer'
          }}
          onClick={() => setActiveProject(null)}
        >
          <FiHome />
        </div>

        {/* Divider */}
        <div style={{
          width: '32px',
          height: '1px',
          backgroundColor: '#363636',
          margin: '8px 0'
        }}></div>

        {/* Projects List */}
        {projects.map(project => (
          <div 
            key={project.id}
            style={{
              width: '48px',
              height: '48px',
              borderRadius: '50%',
              backgroundColor: activeProject === project.id ? '#363636' : '#2a2a2a',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              cursor: 'pointer',
              fontSize: '18px'
            }}
            onClick={() => setActiveProject(project.id)}
          >
            {project.name.charAt(0).toUpperCase()}
          </div>
        ))}

        {/* Add Project Button */}
        <div 
          style={{
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            backgroundColor: '#2a2a2a',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            cursor: 'pointer'
          }}
          onClick={() => setShowCreateModal(true)}
        >
          <FiPlus />
        </div>
      </div>

      {/* User Profile with ID Functionality */}
      <div 
        ref={userMenuRef}
        style={{
          padding: '12px',
          display: 'flex',
          justifyContent: 'center',
          borderTop: '1px solid #363636',
          position: 'relative'
        }}
      >
        <div 
          style={{
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            backgroundColor: '#363636',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            cursor: 'pointer'
          }}
          onClick={() => setShowUserMenu(!showUserMenu)}
        >
          {user?.photoURL ? (
            <img 
              src={user.photoURL} 
              alt="User" 
              style={{ 
                width: '100%', 
                height: '100%', 
                borderRadius: '50%',
                objectFit: 'cover'
              }} 
            />
          ) : (
            <BsPersonFill />
          )}
        </div>

        {/* User Menu Dropdown */}
        {showUserMenu && (
          <div style={{
            position: 'absolute',
            bottom: '70px',
            left: '16px',
            backgroundColor: '#2a2a2a',
            borderRadius: '8px',
            padding: '12px',
            width: '200px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            zIndex: 1000
          }}>
            {/* User Info */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '12px',
              paddingBottom: '12px',
              borderBottom: '1px solid #363636'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                backgroundColor: '#363636',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white'
              }}>
                {user?.photoURL ? (
                  <img 
                    src={user.photoURL} 
                    alt="User" 
                    style={{ 
                      width: '100%', 
                      height: '100%', 
                      borderRadius: '50%',
                      objectFit: 'cover'
                    }} 
                  />
                ) : (
                  <BsPersonFill />
                )}
              </div>
              <div>
                <div style={{ color: 'white', fontWeight: 'bold' }}>
                  {user?.displayName || 'User'}
                </div>
                <div style={{ color: '#aaa', fontSize: '12px' }}>
                  ID: {user?.uid?.substring(0, 8) || 'N/A'}
                </div>
              </div>
            </div>

            {/* Logout Button */}
            <div 
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                padding: '8px',
                color: 'white',
                cursor: 'pointer',
                borderRadius: '4px',
                ':hover': {
                  backgroundColor: '#363636'
                }
              }}
              onClick={logout}
            >
              <FiLogOut />
              <span>Log Out</span>
            </div>
          </div>
        )}
      </div>

      {/* Create Project Modal */}
      {showCreateModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.7)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: '#2a2a2a',
            padding: '20px',
            borderRadius: '8px',
            width: '300px'
          }}>
            <h3 style={{ color: 'white', marginBottom: '16px' }}>Create Project</h3>
            <input
              type="text"
              placeholder="Project name"
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              style={{
                width: '100%',
                padding: '8px',
                marginBottom: '16px',
                backgroundColor: '#1e1e1e',
                border: '1px solid #363636',
                color: 'white',
                borderRadius: '4px'
              }}
              autoFocus
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#363636',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
                onClick={() => setShowCreateModal(false)}
              >
                Cancel
              </button>
              <button
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#4a4a4a',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
                onClick={handleCreateProject}
                disabled={!newProjectName.trim()}
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;