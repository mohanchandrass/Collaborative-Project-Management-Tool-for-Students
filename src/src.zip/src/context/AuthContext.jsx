import React, { createContext, useState } from 'react';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState({
    id: 'user1',
    username: 'demo_user',
    email: 'demo@example.com',
    avatar: 'https://i.pravatar.cc/150?img=3',
    groups: ['group1', 'group2']
  });

  const updateUserGroups = (groupId) => {
    setCurrentUser(prev => ({
      ...prev,
      groups: [...prev.groups, groupId]
    }));
  };

  // Mock login/logout functions for demo purposes
  const login = () => {
    setCurrentUser({
      id: 'user1',
      username: 'demo_user',
      email: 'demo@example.com',
      avatar: 'https://i.pravatar.cc/150?img=3',
      groups: ['group1', 'group2']
    });
    return Promise.resolve();
  };

  const logout = () => {
    setCurrentUser(null);
    return Promise.resolve();
  };

  return (
    <AuthContext.Provider value={{ 
      currentUser, 
      updateUserGroups,
      login,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
};