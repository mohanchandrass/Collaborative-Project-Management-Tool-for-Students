// src/context/index.js
export { AuthProvider, AuthContext } from './AuthContext';
export { ProjectProvider, ProjectContext } from './ProjectContext';
export { TaskProvider, TaskContext } from './TaskContext';